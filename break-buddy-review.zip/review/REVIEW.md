# Break Buddy — Revisión Completa del Flujo de Pago
**Fecha:** 2026-07-18  
**Estado del deploy:** ✅ CORS fix activo desde 2026-07-18 11:50 UTC

---

## Resumen ejecutivo

El código del flujo nombre → equipo → pago → equipo formado es **correcto y sólido** en su lógica interna. La única inconsistencia crítica activa es de **dominio**: el `back_url` de los planes de MP siempre devuelve al usuario a `https://sipwell.app`, pero si el usuario entró por `hydration-break-buddy--luchoinco.replit.app`, pierde su sesión y su estado de localStorage al llegar a sipwell.app.

---

## Inconsistencias encontradas

### ❌ 1. CRÍTICA — Dos dominios, un back_url fijo

**Qué pasa:**
- MP plans tienen `back_url = "https://sipwell.app"` (fijo, no puede ser dinámico en preapproval plans)
- La app es accesible desde DOS dominios:
  - `https://sipwell.app` (dominio personalizado)
  - `https://hydration-break-buddy--luchoinco.replit.app` (dominio Replit)
- `localStorage` es **domain-scoped**: las claves `bb-pending-payment`, `bb-pending-plan`, `bb-pending-team-name` guardadas en `luchoinco.replit.app` NO son accesibles desde `sipwell.app`
- `bb_session` cookie (httpOnly, sameSite=lax) también es domain-scoped: si el usuario creó su usuario desde `luchoinco.replit.app`, el cookie no viaja a `sipwell.app`

**Escenario que falla:**
```
Usuario entra por luchoinco.replit.app
→ Ingresa nombre (cookie bb_session seteada en luchoinco.replit.app)
→ Elige plan → paga en MP
→ MP redirige a sipwell.app?preapproval_id=xxx
→ En sipwell.app: localStorage vacío → hasPendingPayment = false
→ App.tsx línea 35: effectiveMode = mode (null) → muestra pantalla de bienvenida
→ Cookie bb_session no existe en sipwell.app → 401 en /api/payments/:token/status
→ EQUIPO NUNCA SE CREA ✗
```

**Escenario que funciona:**
```
Usuario entra por sipwell.app
→ Todo ocurre en el mismo dominio
→ MP devuelve a sipwell.app → localStorage presente → flujo completo ✓
```

**Fix requerido:**
- **Opción A (recomendada):** Redirigir `luchoinco.replit.app` → `sipwell.app` en el servidor. Agregar en `app.ts` antes del CORS:
  ```ts
  app.use((req, res, next) => {
    if (
      process.env.NODE_ENV === "production" &&
      process.env.CANONICAL_URL &&
      req.hostname !== new URL(process.env.CANONICAL_URL).hostname
    ) {
      return res.redirect(301, process.env.CANONICAL_URL + req.url);
    }
    next();
  });
  ```
  Y setear `CANONICAL_URL=https://sipwell.app` en producción.
  
- **Opción B (inmediata, sin código):** Comunicar claramente que solo `sipwell.app` es la URL de producción. No compartir ni acceder por la URL de Replit.

---

### ⚠️ 2. MENOR — Webhook no puede crear el equipo si llega antes que el frontend

**Qué pasa:**
En `webhooks.ts` líneas 108-112, cuando MP notifica `subscription_preapproval` con status `authorized`, el webhook intenta actualizar `teamsTable` buscando por `mpPreapprovalId`. Pero en el primer pago, el equipo **todavía no existe** (se crea en el frontend tras el polling).

**Consecuencia:** La línea `UPDATE teams SET subscriptionStatus = 'active' WHERE mpPreapprovalId = '...'` ejecuta con 0 rows afectadas — silenciosamente no hace nada. El equipo se crea correctamente después mediante el frontend, con `subscriptionStatus = 'active'` ya seteado en la transacción de `teams.ts:115`.

**Por qué NO es un bug bloqueante:** El webhook SÍ actualiza `paymentsTable.status = 'approved'` (líneas 86-91), que es lo que desbloquea el polling del frontend. El `subscriptionStatus` del equipo se setea correctamente en la creación. Para renovaciones mensuales (`subscription_authorized_payment`), el equipo ya existe → la actualización funciona.

**Fix opcional (no urgente):** Aceptar este comportamiento como correcto y documentarlo.

---

### ✅ 3. VERIFICADO — Token de pago se consume atómicamente

`teams.ts` líneas 77-99: transacción única que hace UPDATE + condición `consumed = false AND status = 'approved' AND userId = req.userId`. Si falla cualquier paso, rollback automático. No es posible crear dos equipos con el mismo token. ✓

### ✅ 4. VERIFICADO — teamName sobrevive el redirect

`TeamOnboarding.tsx` línea 162: se guarda `bb-pending-team-name` en localStorage antes de redirigir a MP. Se recupera en línea 55-57 al inicializar el estado. ✓ (Siempre que el redirect sea al mismo dominio.)

### ✅ 5. VERIFICADO — userId se valida server-side

`teams.ts` línea 86: el token de pago debe pertenecer al mismo `userId` extraído del session cookie. No es posible usar el token de otro usuario. ✓

### ✅ 6. VERIFICADO — CORS permite ambos dominios

`app.ts` líneas 38-44: permite tanto `ALLOWED_ORIGIN` (sipwell.app) como todos los dominios en `REPLIT_DOMAINS` automáticamente. ✓

### ✅ 7. VERIFICADO — Detección de retorno de MP

`App.tsx` línea 35: `effectiveMode` usa `mpPreapprovalId && hasPendingPayment` para forzar modo equipo aunque `mode` sea null. ✓  
`TeamOnboarding.tsx` línea 47: detecta `preapproval_id` en URL para saltar a `pay-pending`. ✓

---

## Estado de variables de entorno (producción)

| Variable | Valor | Estado |
|---|---|---|
| `ALLOWED_ORIGIN` | `https://sipwell.app` | ✅ |
| `APP_PUBLIC_URL` | `https://sipwell.app` | ✅ |
| `MP_PREAPPROVAL_PLAN_ID_TEAM` | `1cbeba0be7bd49cc92d3ee343c18a04f` | ✅ |
| `MP_PREAPPROVAL_PLAN_ID_COMPANY` | `d38999bc63124981b04c6a1a2907284b` | ✅ |
| `MP_ACCESS_TOKEN_TEST_SELLER` | presente | ✅ (test) |
| `MP_ACCESS_TOKEN` | presente | ✅ |
| `SESSION_SECRET` | presente | ✅ |
| `GMAIL_APP_PASSWORD` | presente | ✅ |

---

## Flujo completo verificado (cuando se accede por sipwell.app)

```
1. Usuario entra a sipwell.app
2. Selecciona "Modo Equipo"
3. Ingresa su nombre → POST /api/users → 201, cookie bb_session seteada
4. Elige "Crear equipo"
5. Ingresa nombre del equipo → guardado en localStorage (bb-pending-team-name)
6. Selecciona plan (Team $5.500 o Company $14.000 ARS/mes)
7. "Ir a pagar" → POST /api/payments/create → 201, checkoutUrl generada
8. localStorage: bb-pending-payment=<token>, bb-pending-plan=<plan>
9. window.location.href = checkoutUrl → usuario en mercadopago.com.ar
10. Usuario ingresa tarjeta y confirma
11. MP redirige a sipwell.app?preapproval_id=<id>
12. App.tsx detecta preapproval_id + bb-pending-payment → effectiveMode="team"
13. TeamOnboarding detecta preapproval_id → step="pay-pending"
14. Polling GET /api/payments/<token>/status cada 2s
15. Webhook MP dispara → paymentsTable.status="approved"
16. Polling devuelve status=approved → step="create-team"
17. useEffect auto-crea equipo → POST /api/teams → 201
18. Transacción: token consumed=true, equipo creado, userId asignado al equipo
19. step="invite-code" → usuario ve su código para compartir ✓
```

---

## Pendientes antes del go-live definitivo

1. **Fix canónico de dominio** (Opción A arriba) — evita el escenario de fallo cuando alguien entra por la URL de Replit
2. **Cambiar tokens y plan IDs de test a producción real de MP** — actualmente usa `MP_ACCESS_TOKEN_TEST_SELLER`
3. **Verificar Gmail App Password** — confirmar que `GMAIL_APP_PASSWORD` es una App Password (no contraseña de cuenta)
4. **URL canónica en back_url de planes MP** — ya está en `https://sipwell.app` ✓
